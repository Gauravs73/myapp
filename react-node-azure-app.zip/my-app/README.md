# React + Node Azure App

Deployed using Azure App Service.